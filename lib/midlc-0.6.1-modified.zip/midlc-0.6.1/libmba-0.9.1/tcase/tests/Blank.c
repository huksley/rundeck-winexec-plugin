#include "common.h"
#include "mba/cfg.h"

int
Blank(int verbose, struct cfg *cfg, char *args[])
{
	tcase_printf(verbose, "done");
    return 0;
}
