/**
 * 
 */
package com.dtolabs.rundeck.core.authorization.providers;

/**
 * @author noahcampbell
 *
 */
public class InvalidCollection extends Exception {

    /**
     * 
     */
    public InvalidCollection() {
        // TODO Auto-generated constructor stub
    }

    /**
     * @param arg0
     */
    public InvalidCollection(String arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    /**
     * @param arg0
     */
    public InvalidCollection(Throwable arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    /**
     * @param arg0
     * @param arg1
     */
    public InvalidCollection(String arg0, Throwable arg1) {
        super(arg0, arg1);
        // TODO Auto-generated constructor stub
    }

}
